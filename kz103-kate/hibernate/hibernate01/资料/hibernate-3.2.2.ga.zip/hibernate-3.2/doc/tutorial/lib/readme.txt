Put all required Hibernate libraries here to run the tutorial.
See lib/README.txt in the Hibernate distribution and the tutorial
chapter in the reference documentation.

You might need other third-party libraries to compile the full
tutorial source code. For example, you will need jsdk.jar if you
want to compile the servlets of the example web application.
